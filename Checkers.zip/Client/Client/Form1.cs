﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class Form1 : Form
    {
        private BindingSource TblPlayersBindingSource = new BindingSource();
        private static HttpClient client = new HttpClient();

        public Form1()
        {
            InitializeComponent();
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client.BaseAddress = new Uri("https://localhost:44350/");
        }

        private void TblPlayersdataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            //bring the game data

            string Name = name_textbox.Text;
            string Pass = password_textBox.Text;
            var parameters = new Dictionary<string, string>();
            parameters["Name"] = Name;
            parameters["Pass"] = Pass;
          
            string path = "api/TblPlayers/byname/" + Name + "/" + Pass;
            HttpResponseMessage response = await client.GetAsync(path);
            var contents = response.Content.ReadAsStringAsync();
            string s = contents.Result;

            if (response.IsSuccessStatusCode && s != "[]") //If we received an answer
            {
                TblPlayersBindingSource.DataSource = await response.Content.ReadAsAsync<IEnumerable<Players>>();
                dataGridView1.DataSource = TblPlayersBindingSource;

                // add games count to player
                string id = contents.Result.Split(',')[0].Substring(7);
                string path2 = "/api/TblPlayers/" + id;
                string g = contents.Result.Split(',')[2].Substring(11);
                int gamesNum = int.Parse(g);
                gamesNum = Convert.ToInt32(g) + 1;

                Players p = new Players();

                p.Id = Convert.ToInt32(id);
                p.Name = Name;
                p.GamesNum = gamesNum;
                p.pw = Pass;


                HttpResponseMessage PutResponse = await client.PutAsJsonAsync(path2, p);

                //add game
                Games game = new Games { IsWin = 0,Player=Name, Time= DateTime.Now };
                string PostPath = "/api/TblGames";
                HttpResponseMessage PostResponse = await client.PostAsJsonAsync<Games>(PostPath, game);

                
                //play!
                var f = new GameForm(game, p);
                f.Show();
            }

            else
            {
                string message = "Wrong UserName or Password, please try again!";
                string caption = "Error Detected in Input";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result = MessageBox.Show(message, caption, buttons);
            }
            // 
            //   var f = new GameForm();
            //   f.Show();



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


    }
}
