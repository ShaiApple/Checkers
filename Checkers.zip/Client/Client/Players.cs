﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public class Players
    {
        public int Id { get; set; }

        public string Name { get; set; }
        public int GamesNum { get; set; }

        public string pw { get; set; }



    }
}
