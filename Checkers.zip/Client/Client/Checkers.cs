﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using Newtonsoft.Json;
using System.Runtime.Remoting.Messaging;

namespace Client
{
    public class Checkers
    {

        public int movesMade = 0;
        public Point tmp;
        public Point drawPoint;
        private Rectangle[,] slots = new Rectangle[4, 8];
        private Holder[,] holders = new Holder[4, 8];
        public const int Players = 2;
        public int player = 1;
        Dictionary<Point, int> occupiedCell = new Dictionary<Point, int>();
        private static HttpClient client = new HttpClient();
        public Games g;


        public void initCheckers(Games game)
        {
            client.BaseAddress = new Uri("https://localhost:44350/");
            g = game;
            drawStart();
            for (int x = 0; x < 4; x++)
            {
                for (int y = 0; y < 8; y++)
                {
                    slots[x, y] = new Rectangle(x * 75, y * 50, 75, 50);
                    holders[x, y] = new Holder();
                    holders[x, y].setValue(Players);
                    holders[x, y].setLocation(new Point(x, y));
                }
            }
        }

        public async void detectHit(Point loc)
        {


            if (loc.Y <= 400 && loc.X <= 300)
            {
                int x = 0;
                int y = 0;

                if (loc.X < 75)
                {
                    x = 0;
                }

                else if (loc.X > 75 && loc.X < 150)
                {
                    x = 1;
                }
                else if (loc.X > 150 && loc.X < 225)
                {
                    x = 2;
                }
                else if (loc.X > 225 && loc.X < 300)
                    x = 3;

                if (loc.Y < 50)
                {
                    y = 0;
                }

                else if (loc.Y > 50 && loc.Y < 100)
                {
                    y = 1;
                }
                else if (loc.Y > 100 && loc.Y < 150)
                {
                    y = 2;
                }
                else if (loc.Y > 150 && loc.Y < 200)
                {
                    y = 3;
                }
                else if (loc.Y > 200 && loc.Y < 250)
                {
                    y = 4;
                }
                else if (loc.Y > 250 && loc.Y < 300)
                {
                    y = 5;
                }
                else if (loc.Y > 300 && loc.Y < 350)
                {
                    y = 6;
                }
                else if (loc.Y > 350 && loc.Y < 400)
                {
                    y = 7;
                }


                // ----------------------
              


                if (movesMade % 2 == 0) //player1
                {

                    if (occupiedCell.ContainsKey(new Point(x, y)))
                    {
                        //  
                        tmp = new Point(x, y);
                        GFX.drawO(tmp, Color.White);

                    }
                    if (!occupiedCell.ContainsKey(new Point(x, y)) && checkPlayermove(tmp, new Point(x, y)) == false || !occupiedCell.ContainsKey(new Point(x, y)) && checkIfEaten(tmp, new Point(x, y), Color.Blue)== false )
                    {
                        MessageBox.Show("click again!");

                    }
                    if (!occupiedCell.ContainsKey(new Point(x, y)) && checkPlayermove(tmp, new Point(x, y)) == true && checkIfEaten(tmp, new Point(x, y), Color.Blue) == true)
                    {

                        drawPoint = new Point(x, y);
                        GFX.drawO(drawPoint, Color.Blue);
                      // checkIfEaten(tmp, drawPoint, Color.Blue);
                        occupiedCell.Add(new Point(x, y), 1);
                        movesMade++;
                        if (drawPoint.Y == 7)
                        {

                            GameOver(g, 1); //blue win!

                        }

                    }
                   
                    if (movesMade % 2 == 1)
                    {
                        occupiedCell.Remove(tmp);
                    }
                }
                else //player2
                {
                    bool pointOk;
                    Point tofromserver = new Point();


                    if (occupiedCell.ContainsKey(new Point(x, y)))
                    {
                        tmp = new Point(x, y);
                        GFX.drawO(tmp, Color.White);

                        do
                        {
                            string path = "api/TblGames/getmove";
                            string json = JsonConvert.SerializeObject(occupiedCell, Formatting.None);

                            HttpResponseMessage PostResponse = await client.PostAsJsonAsync<String>(path, json);
                            var contents = PostResponse.Content.ReadAsStringAsync();
                            string s = contents.Result;
                            s.Split(',');
                            string sx = s[1].ToString();
                            string sy = s[3].ToString();

                            tofromserver = new Point(int.Parse(sx), int.Parse(sy));
                            if (occupiedCell.ContainsKey(tofromserver))
                            {
                                pointOk = false; ; //need another point
                                                   //     MessageBox.Show("Try again!");
                            }
                            else
                            {
                                if (checkServermove(tmp, tofromserver) == false)//not alowed
                                {
                                    pointOk = false;
                                }
                                else
                                {
                                    pointOk = true; //ok
                                }
                            }
                        } while (pointOk == false); //end when the point is not in dictionary

                    }
                    if (!occupiedCell.ContainsKey(tofromserver) )
                    {
                        drawPoint = tofromserver;
                        // checkIfEaten(tmp, drawPoint, Color.Pink);
                        GFX.drawO(drawPoint, Color.Pink);
                        
                        occupiedCell.Add(tofromserver, 2);
                        movesMade++;
                        if (drawPoint.Y == 0)
                        {

                            GameOver(g, 0); //blue lost!

                        }
                    }
                    if (movesMade % 2 == 0)
                    {
                        occupiedCell.Remove(tmp);
                    }

                }

            }

        }
        public bool checkPlayermove(Point from, Point to)
        {
            if (from.X + 1 == to.X && from.Y + 1 == to.Y || from.X - 1 == to.X && from.Y + 1 == to.Y)
            {
                return true;
            }
            if (from.X + 2 == to.X && from.Y + 2 == to.Y)// need to eat
            {
                if (occupiedCell.ContainsKey(new Point(from.X + 1, from.Y + 1)))
                {
                    return true;
                }
                else
                    return false;
            }
            if (from.X - 2 == to.X && from.Y + 2 == to.Y)
            {
                if (occupiedCell.ContainsKey(new Point(from.X - 1, from.Y + 1)))
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        public bool checkServermove(Point from, Point to)
        {
            
            if (from.X + 1 == to.X && from.Y - 1 == to.Y || from.X - 1 == to.X && from.Y - 1 == to.Y)
            {
                return true;
            }
            if (from.X + 2 == to.X && from.Y - 2 == to.Y)// need to eat
            {
                if (occupiedCell.ContainsKey(new Point(from.X + 1, from.Y - 1)))
                {
                    return true;
                }
                else
                    return false;
            }
            if (from.X - 2 == to.X && from.Y - 2 == to.Y)
            {
                if (occupiedCell.ContainsKey(new Point(from.X - 1, from.Y - 1)))
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        public void drawStart()
        {
            //player1
            GFX.drawO(new Point(0, 1), Color.Blue);
            occupiedCell.Add(new Point(0, 1), 1);
            GFX.drawO(new Point(1, 0), Color.Blue);
            occupiedCell.Add(new Point(1, 0), 1);
            GFX.drawO(new Point(2, 1), Color.Blue);
            occupiedCell.Add(new Point(2, 1), 1);
            GFX.drawO(new Point(3, 0), Color.Blue);
            occupiedCell.Add(new Point(3, 0), 1);

            //player2

            GFX.drawO(new Point(0, 7), Color.Pink);
            occupiedCell.Add(new Point(0, 7), 2);
            GFX.drawO(new Point(1, 6), Color.Pink);
            occupiedCell.Add(new Point(1, 6), 2);
            GFX.drawO(new Point(2, 7), Color.Pink);
            occupiedCell.Add(new Point(2, 7), 2);
            GFX.drawO(new Point(3, 6), Color.Pink);
            occupiedCell.Add(new Point(3, 6), 2);

        }

        public bool checkIfEaten(Point from, Point to, Color playerNum)
        {
            bool ans = true;
            if (playerNum == Color.Blue) //player1
            {
                if (from.X + 2 == to.X && from.Y + 2 == to.Y)
                {

                    Point removePoint = new Point(from.X + 1, from.Y + 1);

                    if (occupiedCell[removePoint] == 2)
                    {
                        GFX.drawO(removePoint, Color.White);
                        occupiedCell.Remove(removePoint);
                        GFX.drawO(to, Color.Blue);
                        ans = true;
                    }
                    else
                    {
                        ans= false;
                    }

                }
                if (from.X - 2 == to.X && from.Y + 2 == to.Y)
                {
                    Point removePoint = new Point(from.X - 1, from.Y + 1);
                    if (occupiedCell[removePoint] == 2)
                    {
                        GFX.drawO(removePoint, Color.White);
                        occupiedCell.Remove(removePoint);
                        GFX.drawO(to, Color.Blue);
                        ans = true;
                    }
                    else
                    {
                        ans= false;
                    }
                }

                return ans; //

            }
            else //player2
            {
                if (from.X + 2 == to.X && from.Y - 2 == to.Y)
                {
                    Point removePoint = new Point(from.X + 1, from.Y - 1);
                    if (occupiedCell[removePoint] == 1)
                    {
                        GFX.drawO(removePoint, Color.White);
                        occupiedCell.Remove(removePoint);
                        GFX.drawO(to, Color.Pink);
                        ans = true;
                    }
                    else
                    {
                        ans= false;
                    }
                }
                if (from.X - 2 == to.X && from.Y - 2 == to.Y)
                {
                    Point removePoint = new Point(from.X - 1, from.Y - 1);
                    if (occupiedCell[removePoint] == 1)
                    {
                        GFX.drawO(removePoint, Color.White);
                        occupiedCell.Remove(removePoint);
                        GFX.drawO(to, Color.Pink);
                        ans =  true;
                    }
                    else
                    {
                       ans= false;
                    }
                }

                return ans;


        }
        }

        public async void GameOver(Games game, int isWin)
        {
            Games g = game;

            string getPath = "api/TblGames/foundgame/" + g.Player;
            HttpResponseMessage getresponse = await client.GetAsync(getPath);
            var contents = getresponse.Content.ReadAsStringAsync();

            string[] playerGames = contents.Result.Split('}');
            string lastGameId = playerGames[playerGames.Length - 2].Split(',')[1].Substring(6);

            string putPath = "/api/TblGames/" + lastGameId;


            Games newG = new Games();
            newG.Id = Convert.ToInt32(lastGameId);
            newG.Player = g.Player;
            newG.IsWin = isWin;
            newG.Time = g.Time;

            HttpResponseMessage PutResponse = await client.PutAsJsonAsync(putPath, newG);
            string w="";
            if (isWin == 1) w = "Win!";
            if (isWin == 0) w = "Lost!";
 
            MessageBox.Show("Game over! " + g.Player + w);

        }
    }

    public class Holder
    {
        private Point location;
        private int value = Checkers.Players;
        public void setLocation(Point p)
        {
            location = p;
        }
        public Point getLocation()
        {
            return location;
        }
        public void setValue(int v)
        {
            value = v;
        }
        public int getValue()
        {
            return value;
        }
    }
}
