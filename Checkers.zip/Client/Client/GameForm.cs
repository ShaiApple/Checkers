﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public partial class GameForm : Form
    {
        public GFX engine;
        public Checkers theCheckers;
        public Games game;
        public Players player;
        
        public GameForm(Games g, Players p)
        {
           InitializeComponent();
           game = g;
           player = p;
           MessageBox.Show("Welcome "+ p.Name+ "!"+ "\nId: " + p.Id + " Password: "+ p.pw +" Number of games: " +  p.GamesNum );
        }


        private void GameForm_Load(object sender, EventArgs e)
        {

        }



        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
            Graphics toPass = panel1.CreateGraphics();
            engine = new GFX(toPass);

            theCheckers = new Checkers();

            theCheckers.initCheckers(game);
           

        }

        private void panel1_Click(object sender, EventArgs e)
        {
            Point mouse = Cursor.Position;
            mouse = panel1.PointToClient(mouse);
            theCheckers.detectHit(mouse);
            // theCheckers.detectHit(new Point (2,5));
        }
    }

}
