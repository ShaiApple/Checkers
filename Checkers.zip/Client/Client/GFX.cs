﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Client
{
    public class GFX
    {
        private static Graphics gObject;
        public GFX(Graphics g)
        {
            gObject = g;
            setUpCanvas();
        }
        public void setUpCanvas()
        {
            Brush bg = new SolidBrush(Color.White);
            Pen lines = new Pen(Color.Black, 3);

            gObject.FillRectangle(bg, new Rectangle(0, 0 , 300, 400));
            // |
            gObject.DrawLine(lines, new Point(0, 0), new Point(0, 400));
            gObject.DrawLine(lines, new Point(75,0), new Point(75, 400));
            gObject.DrawLine(lines, new Point(150, 0), new Point(150, 400));
            gObject.DrawLine(lines, new Point(225, 0), new Point(225, 400));
            gObject.DrawLine(lines, new Point(300, 0), new Point(300, 400));
             //-----
            gObject.DrawLine(lines, new Point(0, 0), new Point(300, 0));
            gObject.DrawLine(lines, new Point(0, 50), new Point(300, 50));
            gObject.DrawLine(lines, new Point(0, 100), new Point(300, 100));
            gObject.DrawLine(lines, new Point(0, 150), new Point(300, 150));
            gObject.DrawLine(lines, new Point(0, 200), new Point(300, 200)); //to 400
            gObject.DrawLine(lines, new Point(0, 250), new Point(300, 250));
            gObject.DrawLine(lines, new Point(0, 300), new Point(300, 300));
            gObject.DrawLine(lines, new Point(0, 350), new Point(300, 350));
            gObject.DrawLine(lines, new Point(0, 400), new Point(300, 400));


        }

        public static void drawO(Point p, Color c)
        {
            Pen oPen = new Pen(c, 5);
            SolidBrush oBrush = new SolidBrush(c);
            int xAbs = p.X * 75;
            int yAbs = p.Y * 50;

            gObject.DrawEllipse(oPen, xAbs+(75/2)-15, yAbs+25-15, 30,30);
            gObject.FillEllipse(oBrush, xAbs + (75 / 2) - 15, yAbs + 25 - 15, 30, 30);
        }
    }
}
