﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FinalGame.Model;

namespace FinalGame.Data
{
    public class PlayersDataContext : DbContext
    {
        public PlayersDataContext (DbContextOptions<PlayersDataContext> options)
            : base(options)
        {
        }

        public DbSet<FinalGame.Model.TblPlayers> TblPlayers { get; set; }

    }
}
