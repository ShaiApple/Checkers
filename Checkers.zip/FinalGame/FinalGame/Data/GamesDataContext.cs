﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using FinalGame.Model;

namespace FinalGame.Data
{
    public class GamesDataContext : DbContext
    {
        public GamesDataContext (DbContextOptions<GamesDataContext> options)
            : base(options)
        {
        }

        public DbSet<FinalGame.Model.TblGames> TblGames { get; set; }
    }
}
