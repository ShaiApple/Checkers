﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace FinalGame.Model
{
    public class TblGames
    {
        public int Id { get; set; }
        public string Player { get; set; }
        public DateTime Time { get; set; }
        public int IsWin { get; set; }
    }
}
