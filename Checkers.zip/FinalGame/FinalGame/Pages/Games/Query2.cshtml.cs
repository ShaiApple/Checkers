﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using FinalGame.Data;
using FinalGame.Model;

namespace FinalGame.Pages.Games
{
    public class Query2 : PageModel
    {
        private readonly FinalGame.Data.GamesDataContext _context;

 
        public Query2(FinalGame.Data.GamesDataContext context)
        {
            _context = context;
        }

        public IList<TblGames> TblGames { get;set; }

        public async Task OnGetAsync()  
        {
            TblGames = await _context.TblGames.ToListAsync();
        }
        public async Task OnPostAsync()
        {
            TblGames = await _context.TblGames.ToListAsync();
                       

        }
    }
}
