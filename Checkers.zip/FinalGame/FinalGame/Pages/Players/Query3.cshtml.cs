﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using FinalGame.Data;
using FinalGame.Model;
using Microsoft.AspNetCore.Http;

namespace FinalGame.Pages.Players
{
    public class Query3 : PageModel
    {
        private readonly FinalGame.Data.GamesDataContext _context;
       private readonly FinalGame.Data.PlayersDataContext _Pcontext;


        public Query3(FinalGame.Data.PlayersDataContext context, FinalGame.Data.GamesDataContext context2)
        {
            _context = context2;
            _Pcontext = context;
        }
        [BindProperty]
        public string nameChoice { get; set; }
        public IList<TblPlayers> TblPlayers { get; set; }
        public IList<TblGames> TblGames { get; set; }
        public object MessageBox { get; private set; }
       

        public async Task OnGetAsync()
        {
            TblPlayers = await _Pcontext.TblPlayers.ToListAsync();
            TblGames = await _context.TblGames.ToListAsync();
        }


        public async Task OnPostAsync()
        {
            var x = from game in _context.TblGames
                    where game.Player.Equals(nameChoice)
                    select game;
            TblGames = await x.ToListAsync();

        }
    }
}