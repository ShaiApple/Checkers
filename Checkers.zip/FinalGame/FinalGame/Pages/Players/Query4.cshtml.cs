﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using FinalGame.Data;
using FinalGame.Model;
using Microsoft.AspNetCore.Http;

namespace FinalGame.Pages.Players
{
    public class Query4 : PageModel

    {
      private readonly FinalGame.Data.PlayersDataContext _context;

        public Query4(FinalGame.Data.PlayersDataContext context)
        {
            _context = context;
          
        }

        [BindProperty]
       // public string nameChoice { get; set; }
        public IList<TblPlayers> TblPlayers { get; set; }
       

        public async Task OnGetAsync()
        {
            TblPlayers = await _context.TblPlayers.ToListAsync();
            
        }

        public async Task OnPostAsync()
        {
            TblPlayers = await _context.TblPlayers.ToListAsync();
          //  var x = from player in _context.TblPlayers
             //       select player;
        //    TblPlayers = await x.ToListAsync();

        }
    }
}