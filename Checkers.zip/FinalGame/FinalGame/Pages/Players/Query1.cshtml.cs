﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using FinalGame.Data;
using FinalGame.Model;

namespace FinalGame.Pages.Players
{
    public class Query1 : PageModel
    {
        private readonly FinalGame.Data.PlayersDataContext _context;

 
 public Query1(FinalGame.Data.PlayersDataContext context)
        {
            _context = context;
    
        }

        public IList<TblPlayers> TblPlayers { get;set; }

        public async Task OnGetAsync()  
        {
            TblPlayers = await _context.TblPlayers.ToListAsync();
        }
        public async Task OnPostAsync()
        {
            TblPlayers = await _context.TblPlayers.ToListAsync();
                       

        }
    }
}
